# GDP Project

## Covvac App
## Team  Gandora :

Sai Varsha Vellanki

Sreenidhi Madala

Prashansa Ambarkar

Praneeth Vallabhaneni

## Description :
COVVAC is here to help you protect yourself from the virus and decrease the risk of infecting other people in your community and around the world.Our App helps you know if you are eligible to take the vaccine and what precautions and considerations  you can follow . our app collect your health information and based on the record it will display required result information 

## Motive :
The COVVAC is here to help you protect yourself from the virus and decrease the risk of infecting other people in your community and around the world.Your safety is a top priority, and there are many reasons to get vaccinated. None of the COVID-19 vaccines contain the live virus that causes COVID-19 so a COVID-19 vaccine cannot make you sick.
The main motive of our website is to help you know if you are eligible to take the vaccine and what is the risk rate of vaccine based on your health record.









## App Name and Logo :
COVVAC website  by Team Gandora 

## Sequence of the application :

### Home page

User  can see why covacc information and what our app does along with user login and user Registration

#### Login & Registration

A user needs to register himself/herself to login into the page. All the details as per requirement must be filled in order to register. After the user is a registered member of our page, he/she can login into the web page.





#### Health Form

After login in to Covvac user must provide health records to get their personal vaccination information



#### Covid Info

users will be able to go through  each individual page to get  covid related information 

#### Vaccine Info

All the required data regarding vaccination will be provided to user and also user will be able to access their personal vaccine page where they can see the results in detail.

## Contributors :

  <img src="vsv.png" alt="drawing" width="150" style="border-radius:50%" />                  <img src="SM.png" alt="drawing" width="150" style="border-radius:50%" /> 
 <img src="PA.png" alt="drawing" width="150" style="border-radius:50%" />               <img src="dp.jpeg" alt="drawing" width="150" style="border-radius:50%" />              
       
   
  [Sai Varsha Vellanki](https://github.com/cherryvarsha99) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  [Sreenidhi Madala](https://github.com/Sreenidhi17)  &nbsp;&nbsp;&nbsp;&nbsp;   [Prashansa Ambarkar](https://github.com/PrashansaAmbarkar)  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   [Praneeth Vallabhaneni](https://github.com/praneethvallabhaneni)

